import pandas as pd
import matplotlib.pyplot as plt
import numpy as np


# 1) print the id of the students getting the maximum score (100)
def get_id_students_max_score(exams):
    res = []
    for ids,_,_,_,_,_,i in exams.to_numpy():
        if i == 100:
            res.append(ids)
    return res


# 2) print the race/ethnicity of the studens 1624,1963,1150
def get_ethnicity(df,ids):
    print(df[df.id == ids]["race/ethnicity"].item())
    
    
# 3) search for the id and gender of the student that obtained the highest score in math that did not take the test_prep_course 
def highest_score_no_preparation(df):
    max_score = 0
    idstudent = 0
    genderstudent = 0
    for ids,gender,_,_,_,prep,score in df.to_numpy():
        if prep == "none":
            if score > max_score:
                max_score = score
                idstudent = ids
                genderstudent = gender
          
    print("Best student that do not takes any preparation course:")
    print("id: ",idstudent)
    print("gender: ",genderstudent)
    print("score: ",max_score)
    
    
#4) print the parents education level of the following students: [1450,1451,1452,1453,1454]
def load_parents():
    parents = dict()
    f = open("DATA/parent_eductaion_level.csv", "r")
    for i in f.readlines()[1:]:
        code, text = i.split(",")

        parents[int(code)] = text[:-1]

    f.close()
    return parents

def print_parents_edu(exams):
    parents = load_parents()
    for i in  [1450,1451,1452,1453,1454]:
        parent_ed = exams[exams.id == i].parent_education_level.item()
        print(i, parents[parent_ed])
        
        
#5) make an unique plot with distributions **plt.hist(list)** of scores, gender, lunch	test_prep_course
# in the same plot containing the histogram of exam scores add the mean (red) and standard deviation +- (green).

def my_plot(exams):
    plt.figure(figsize=(15,4))
    plt.subplot(141)
    plt.title("Exam scores")
    plt.hist(exams.math)
    avg = np.mean(exams.math)
    plt.vlines(avg,0,290,color="red",label="mean")
    plt.vlines(avg-np.std(exams.math),0,290,color="green",label="std")
    plt.vlines(avg+np.std(exams.math),0,290,color="green")
    plt.legend()
    plt.subplot(142)
    plt.title("Genders")
    plt.hist(exams.gender)
    plt.subplot(143)
    plt.title("Standard / reduced lunch")
    plt.hist(exams.lunch)
    plt.subplot(144)
    plt.title("pre course?")
    plt.hist(exams.test_prep_course)
    plt.show()
    
    
    
exams = pd.read_csv("DATA/exams.csv")
# 1)
ids = get_id_students_max_score(exams)
print(ids)

# 2)
get_ethnicity(exams,1624)
get_ethnicity(exams,1963)
get_ethnicity(exams,1150)

# 3)
highest_score_no_preparation(exams)


# 4)
print_parents_edu(exams)

# 5)
my_plot(exams)
