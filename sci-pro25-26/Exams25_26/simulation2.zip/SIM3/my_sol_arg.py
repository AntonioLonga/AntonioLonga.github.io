# %%
import argparse
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


# =====================================================
#  Functions
# =====================================================

def max_mobility_distance(data: pd.DataFrame):
    """Print participant and day with the maximum mobility distance."""
    res = data.loc[data.mobility_distance.idxmax()]
    print(f"Participant ID: {res.participant_id}\tDay: {res.day}")


def average_call_dur_in_range(data: pd.DataFrame,
                              min_PSS_score: float = 10,
                              max_PSS_score: float = 15) -> float:
    """Return average call duration for participants within a PSS score range."""
    tmp = data[(data.PSS_score >= min_PSS_score) & (data.PSS_score <= max_PSS_score)]
    return tmp.call_duration.mean()


def write_summary(data: pd.DataFrame,
                  user_id_list: list,
                  summary_path: str = "summary.txt",
                  column_names: list = None):
    """Compute and write the average values of specified columns for selected users."""
    if column_names is None:
        column_names = [c for c in data.columns if c not in ["participant_id", "day"]]

    res = []
    for user in user_id_list:
        sub_data = data[data.participant_id == user]
        res.append(f"User ID: {user}")
        for name in column_names:
            mean_val = sub_data[name].mean()
            res.append(f"\t{name}: {mean_val:.2f}")
        res.append("")

    text = "\n".join(res)
    with open(summary_path, "w") as file:
        file.write(text)

    print(f"Summary saved to: {summary_path}")
    print(text)


def plot_participant_summary(data: pd.DataFrame, participant_id: int):
    """Plot PSS_score and sleep_duration over 30 days for a given participant."""
    subset = data[data.participant_id == participant_id]
    days = subset.day.to_numpy()

    pss = subset.PSS_score.to_numpy()
    sleep = subset.sleep_duration.to_numpy()

    fig, ax = plt.subplots(1, 2, figsize=(10, 3))

    # PSS plot
    ax[0].plot(days, pss, "o-", label="PSS")
    ax[0].axhline(pss.mean(), linestyle="dashed", color="red")
    ax[0].set_title(f"PSS score of user {participant_id}")
    ax[0].set_xlabel("Day")
    ax[0].set_ylabel("PSS score")
    ax[0].grid(alpha=0.3)

    # Sleep duration plot
    ax[1].plot(days, sleep, "o-", label="Sleep Duration", color="tab:blue")
    ax[1].axhline(sleep.mean(), linestyle="dashed", color="red")
    ax[1].set_title(f"Sleep Duration of user {participant_id}")
    ax[1].set_xlabel("Day")
    ax[1].set_ylabel("Sleep duration (hours)")
    ax[1].grid(alpha=0.3)

    plt.tight_layout()
    plt.show()


# =====================================================
#  Main
# =====================================================

def main():
    parser = argparse.ArgumentParser(
        description="Analyze stress detection dataset and produce summary statistics."
    )
    parser.add_argument(
        "--data_path",
        type=str,
        default="data/stress_detection.csv",
        help="Path to the dataset CSV file."
    )
    parser.add_argument(
        "--summary_path",
        type=str,
        default="summary.txt",
        help="Path where the summary file will be saved."
    )

    args = parser.parse_args()

    # Load dataset
    data = pd.read_csv(args.data_path)
    print(f"Loaded dataset with {len(data)} rows from {args.data_path}\n")

    # Run analyses
    max_mobility_distance(data)
    avg_dur = average_call_dur_in_range(data, min_PSS_score=3, max_PSS_score=10)
    print(f"\nAverage call duration (PSS 3–10): {avg_dur:.4f}\n")

    # Write summary
    user_id_list = [1, 3, 5]
    column_names = ["Agreeableness", "Extraversion"]
    write_summary(data, user_id_list, args.summary_path, column_names)

    # Plot participant data
    plot_participant_summary(data, participant_id=10)


if __name__ == "__main__":
    main()
