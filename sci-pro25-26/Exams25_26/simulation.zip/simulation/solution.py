
import pandas as pd
import matplotlib.pyplot as plt
import argparse
import os



def store_avg_median(songs):
    
    year = "1922"
    songs_in_year = songs[songs['year'] == year]

    avg_popularity = songs_in_year['popularity'].mean()
    median_duration_ms = songs_in_year['duration_ms'].median()
    
    filename = f"{year}_metrics.txt"
    output_content = (
        f"Metrics for the year {year}:\n"
        f"Average Popularity: {avg_popularity:.2f}\n"
        f"Median Duration (ms): {median_duration_ms:.0f}\n"
    )
    
    with open(filename, 'w') as f:
        f.write(output_content)
        
    print(f">> Metrics for {year} stored in '{filename}'")
    
    
def ms_to_mmssms(ms: int) -> str:
    milliseconds = ms % 1000
    seconds_total = ms // 1000
    seconds = seconds_total % 60
    minutes = seconds_total // 60
    return f"{minutes}:{seconds}:{milliseconds}"

def longest_song_in_year(songs,year=1923):
    year = str(year).split('-')[0]
    duration = songs[songs['release_date'] == '1923'].duration_ms.max()
    name = songs[songs['duration_ms'] == duration].name.item()   

    res = (name, ms_to_mmssms(duration))

    return res 

def my_plot(songs_df):
    
    years = [1922, 1923, 1924]
    
    fig, axes = plt.subplots(1, 3, figsize=(12, 4))
    
    for i, year in enumerate(years):
        subset = songs_df[songs_df['year'] == str(year)]['danceability']
        
        axes[i].hist(subset, bins=10)
        axes[i].set_title(f"Danceability dist. {year}")
        axes[i].set_xlabel("Danceability")
        axes[i].set_ylabel("Count")
    
    plt.tight_layout()
    plt.savefig("Danceability.pdf")
    plt.show()

def most_frequent_artist(songs, artists, year):
    songs_in_year = songs[songs['year'] == str(year)]
    
    artist_counts = songs_in_year['id_artists'].value_counts()
        
    most_frequent_id = artist_counts.index[0]
    num_songs = artist_counts.iloc[0]
    
    artist_name = artists[artists['id'] == most_frequent_id]['name'].iloc[0]

    print(f"The artist: {artist_name}")
    print(f"Played {num_songs} songs in {year}")



if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Exam simulation")
    
    parser.add_argument(
        '--songs_path', 
        type=str, 
        default='data/songs.csv', 
        help='Path for songs.csv (default: songs.csv)'
    )
    parser.add_argument(
        '--artists_path', 
        type=str, 
        default='data/artists.csv', 
        help='Path for artists.csv (default: artists.csv)'
    )
    
    args = parser.parse_args()
    
    
    # es 1
    songs_df = pd.read_csv(args.songs_path)
    artists_df = pd.read_csv(args.artists_path)
    
    
    songs_df['year'] = songs_df['release_date'].str.split('-').str[0]
    
        
    print("\n--- Es 2 ---")
    store_avg_median(songs_df)
    
    
    print("\n--- Es 3 ---")
    title, duration_formatted = longest_song_in_year(songs_df, year=1923)
    print(f">> ('{title}', '{duration_formatted}')")

    print("\n--- Es 4 ---")
    my_plot(songs_df)
    print(">> Stored in 'Danceability.pdf'.")

    print("\n--- Es 5 ---")
    most_frequent_artist(songs_df, artists_df, year=1924)