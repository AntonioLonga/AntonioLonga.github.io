import pandas as pd
import matplotlib.pyplot as plt
import numpy as np




edicole = pd.read_csv("DATA/Edicole.csv")
fontane = pd.read_csv("DATA/Fontane.csv",sep=";")

def counter(df,key):
    print(len(df[df.NIL == key].NIL))



counter(fontane,"GORLA - PRECOTTO")
counter(edicole,"CITTA' STUDI")



def plot_newskiosk(edicole):
    tmp = dict()
    for i in list(edicole.forma_vendita_edicole):
        if i in tmp:
            tmp[i] += 1
        else:
            tmp[i] = 1

    plt.bar(np.arange(len(tmp)),list(tmp.values()))
    plt.xticks(np.arange(4),list(tmp.keys()),rotation=45)
    plt.show()

plot_newskiosk(edicole)


def same_quarter(edicole,fontane,key):
    
    ed = edicole[edicole.NIL == key]
    fo = fontane[fontane.NIL == key]
    
    print("The news kiosk are")
    for i in ed.via_denominazione_portale:
        print(i)
    print("The fountain objectID are:")
    for i in fo.objectID:
        print(i)
        
same_quarter(edicole,fontane,"DUOMO")


def nearest_fountain(fontane):
    lat = list(fontane.LAT_Y_4326)
    lon = list(fontane.LONG_X_4326)
    
    id1 = -1
    id2 = -1
    D = 1000
    for i in range(len(lat)):
        p1 = lat[i]
        p2 = lon[i]
        for j in range(i+1,len(fontane)):
            d = np.sqrt((lat[i]-lat[j])**2 + (lon[i]-lon[j])**2)
            
            if d < D:
                D = d
                id1 = i
                id2 = j
                
    print("the closest fountains are", id1,id2)
    print("their distance is:",D)
            
nearest_fountain(fontane)



def load_app(path):
    f = open(path, "r")
    data = f.readlines()
    f.close()

    new_data = []
    for i in data:
        tmp = []
        for j in i.split(","):
            fix_j = j.replace(" ","")
            fix_j = fix_j.replace("€","")
            fix_j = fix_j.replace("euro","")
            fix_j = fix_j.replace("E","")
            fix_j = fix_j.replace("\t","")
            fix_j = fix_j.replace("\n","")
            tmp.append(fix_j)
        if len(tmp)>3:
            new_data.append(tmp)
    return new_data
    
app = load_app("DATA/apartments.txt")

def search_closest(pos,edic):
    lon = edicole.LONG_X_4326
    lat = edicole.LAT_Y_4326
    
    D = 10000
    idx = 0
    for i in range(len(lon)):
        d = np.sqrt((lat[i]-pos[0])**2 + (lon[i]-pos[1])**2)
        if d < D:
            D = d
            idx = i
            
    return idx,D

for name,cost,x,y in app:
    idx,d = search_closest((float(x),float(y)),edicole)
    
    print(name,cost,edicole.iloc[idx].via_denominazione_portale,d)