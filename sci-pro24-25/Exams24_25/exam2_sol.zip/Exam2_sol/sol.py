import pandas as pd
import matplotlib.pyplot as plt

# mio
df = pd.read_csv("data/car_price_dataset.csv")


# mio
def get_most_expensive(df):
    row = df[df.Price == max(df.Price)]
    print(row.Brand.item(),row.Model.item(),row.Year.item())

get_most_expensive(df)



# mio
def get_most_expensive_filter(df,eng_size=None,year=None,tran=None):
    if eng_size != None:
        df = df[df.Engine_Size < eng_size]
    if year != None:
        df = df[df.Year == year]
    if tran != None:
        df = df[df.Transmission == tran]
    row = df[df.Price == max(df.Price)]

    return row.Brand.item(), row.Model.item()

print(get_most_expensive_filter(df))
print(get_most_expensive_filter(df,eng_size=2.3))
print(get_most_expensive_filter(df,eng_size=2.3,year=2002))
print(get_most_expensive_filter(df,eng_size=2.3,year=2002,tran="Manual"))



# mio
def get_prices(df,fuel="Electric"):
    res = dict()
    for _,d in df.groupby("Year"):
        d = d[d.Fuel_Type == fuel]
        res[d.Year.to_numpy()[0]] = d.Price.mean()
    return res


# mio
def get_price_correct(df,fuel):
    res = dict()
    for _,d in df.groupby("Year"):
        M = d.Price.mean()
        d = d[d.Fuel_Type == fuel]
        res[d.Year.to_numpy()[0]] = d.Price.mean() - M
    return res


# mio
ele = get_price_correct(df,fuel="Electric")
hyb = get_price_correct(df,fuel="Hybrid")
X = list(ele.keys())
plt.plot(X,ele.values(),label="Electric")
plt.plot(X,hyb.values(),label="Hybrid")
plt.ylabel("Price difference")
plt.xlabel("Year")
plt.legend()
plt.savefig("fig.png")
plt.show()
