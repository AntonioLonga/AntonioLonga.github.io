import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import json #optional


# 1. NOTE that I'm using relative path!
# do not use var/home/................./data/user_behavior_dataset.csv
data = pd.read_csv("data/user_behavior_dataset.csv")

# 2
def max_usage(data):
    max_usage = data["App Usage Time (min/day)"].max() # get the max
    age = data[data["App Usage Time (min/day)"] == max_usage].Age.item() # filter, get Age, get item
    print(age)

max_usage(data)

# 3 

# remember the default values
def OS_count(data,min_age=18,max_age=40):
    d = data[data.Age >= min_age] # filter on min_age
    d = d[d.Age <= max_age] # second filter on max age
    
    # get the OS column, convert to numpy, use unique function of numpy with return counts = true
    os,counts=np.unique(d["Operating System"].to_numpy(),return_counts=True)
    
    # fill the dict.
    res = dict()
    for i in range(len(os)):
        res[os[i]] = counts[i]
    return res

min_age = 30
max_age = 35
dict_os_count = OS_count(data,min_age,max_age)

# 4
# bellow is a possible solution:

def data_usage_by_age_and_os(dataset):
    # Initialize summary dictionary with structure for each age group and OS type
    data_summary = {
        "Young": {"Android": {"average_data_usage": 0, "user_count": 0},
                  "iOS": {"average_data_usage": 0, "user_count": 0}},
        "Middle-aged": {"Android": {"average_data_usage": 0, "user_count": 0},
                        "iOS": {"average_data_usage": 0, "user_count": 0}},
        "Senior": {"Android": {"average_data_usage": 0, "user_count": 0},
                   "iOS": {"average_data_usage": 0, "user_count": 0}}
    }
    
    # Separate dictionary to keep running totals for data usage in each category
    total_data_usage = {
        "Young": {"Android": 0, "iOS": 0},
        "Middle-aged": {"Android": 0, "iOS": 0},
        "Senior": {"Android": 0, "iOS": 0}
    }
    
    # Iterate over each record in the dataset
    for _, entry in dataset.iterrows():
        age = entry["Age"]
        os_type = entry["Operating System"]
        data_usage = entry["Data Usage (MB/day)"]
        
        # Determine age group based on age
        if 18 <= age <= 29:
            age_group = "Young"
        elif 30 <= age <= 49:
            age_group = "Middle-aged"
        else:
            age_group = "Senior"
        
        # Update user count and total data usage for the specific age group and OS
        data_summary[age_group][os_type]["user_count"] += 1
        total_data_usage[age_group][os_type] += data_usage
    
    # Calculate average data usage per user for each age group and OS
    for age_group, os_data in data_summary.items():
        for os_type in os_data:
            user_count = os_data[os_type]["user_count"]
            # Only calculate average if there are users in this category
            if user_count > 0:
                os_data[os_type]["average_data_usage"] = (
                    total_data_usage[age_group][os_type] / user_count
                )
    
    return data_summary
data_analysis = data_usage_by_age_and_os(data)



# 5 simplest solution
with open("dict.txt", 'w') as file:
    file.write(str(data_analysis))
    
# 5 better solution
def save_pretty_data_summary(data_summary, filename="dict_pretty.txt"):
    indent=2
    def format_indented(line, level):
        return " " * (indent * level) + line + "\n"
    
    with open(filename, "w") as file:
        for age_group, os_data in data_summary.items():
            file.write(f"{age_group}:\n")
            for os_type, stats in os_data.items():
                file.write(format_indented(f"{os_type}:", 1))
                for key, value in stats.items():
                    file.write(format_indented(f"{key}: {value}", 2))
                    
save_pretty_data_summary(data_analysis, filename="dict_pretty.txt")                

# 5 with json library 
def save_data_summary_json(data_summary, filename):
    with open(filename, "w") as file:
        json.dump(data_summary, file, indent=4)
        
save_data_summary_json(data_analysis, filename="dict_json.json")
    

fig, axs = plt.subplots(1, 2,figsize=(10,3))
axs[0].hist(data["Operating System"])
axs[0].set_title("OS used")
axs[0].set_ylabel("Count")
axs[0].set_xlabel("OS")

axs[1].hist(data["Age"])
axs[1].set_title("Age distribution")
axs[1].set_ylabel("Count")
axs[1].set_xlabel("Age")

plt.savefig("myplot.pdf")
plt.show()

