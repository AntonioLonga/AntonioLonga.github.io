import pandas as pd
import numpy as np
import matplotlib.pyplot as plt


songs = pd.read_csv("data/songs.csv")
artists = pd.read_csv("data/artists.csv")


def max_popularity(songs):
    a = songs[songs.popularity == songs.popularity.max()]
    print(a.name.item(), a.duration_ms.item()/1000)
    
max_popularity(songs)


# song > di 3 min, < di 4 min with max popularity
def max_popularity_with_duration(songs,min_allowed_duration=3,max_allowed_duration=4):
    short_songs = songs[songs.duration_ms < max_allowed_duration*60*1000]
    short_songs = short_songs[short_songs.duration_ms > min_allowed_duration*60*1000]
    return short_songs[short_songs.popularity == short_songs.popularity.max()].name.item()

max_popularity_with_duration(songs,3,4),max_popularity_with_duration(songs)


def popularity_correlation(songs,artists):
    res = dict()
    for uid in artists.id:
        art_pop = artists[artists.id == uid].popularity.item()
        song_pop = songs[songs.id_artists == uid].popularity.mean()
        res[uid] = (art_pop,song_pop )
        
    plt.scatter(np.array(list(res.values()))[:,1],np.array(list(res.values()))[:,0])
    plt.ylabel("Artist popularity")
    plt.xlabel("Average songs popularity")
    plt.title("Correlation between artists and songs popularity")
    plt.savefig("fig.png")
    plt.show()

popularity_correlation(songs,artists)



import pandas as pd

def summary(songs, artists, acousticness_threshold=0.995):
    filtered_songs = songs[songs['acousticness'] > acousticness_threshold]
    merged_data = filtered_songs.merge(artists, left_on='id_artists', right_on='id', suffixes=('_song', '_artist'))

    summary_data = merged_data.groupby('name_artist').agg(
        avg_duration=('duration_ms', lambda x: round(x.mean() / 1000, 2)),  # Convert ms to seconds
        avg_acousticness=('acousticness', 'mean')  # Average acousticness
    ).reset_index()
    with open('summary.txt', 'w') as file:
        file.write(f"Acousticness Threshold: {acousticness_threshold}\n")
        file.write("Artist Name, Average Duration (seconds), Average Acousticness\n")
        for _, row in summary_data.iterrows():
            file.write(f"{row['name_artist']}, {row['avg_duration']}, {round(row['avg_acousticness'], 3)}\n")

    print("Summary written to 'summary.txt'")

summary(songs,artists)
